package com.drauddetector.exception;

public class FraudDetectorException extends Exception {

	private static final long serialVersionUID = 1L;

	public FraudDetectorException(String message) {
		super(message);
	}
}
