package com.frauddetector.constants;

public interface FraudDetectorConstants {

	public static final String CSV_TRAINDATA_FILE_PATH = "C:\\Users\\lnc\\FraudDetector\\FraudDetector\\traindata.csv";
	public static final String ARFF_TRAINDATA_FILE_PATH = "C:\\Users\\lnc\\FraudDetector\\FraudDetector\\traindata.arff";
	public static final String ARFF_TESTDATA_FILE_PATH = "C:\\Users\\lnc\\FraudDetector\\FraudDetector\\testdata.arff";
	
}
