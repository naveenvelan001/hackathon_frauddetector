package com.frauddetector.impl;

import java.io.File;
import java.io.IOException;

import com.drauddetector.exception.FraudDetectorException;
import com.frauddetector.constants.FraudDetectorConstants;

import weka.classifiers.functions.Logistic;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
import weka.core.converters.ConverterUtils.DataSource;

public class FraudDetectorImpl {

	private static void convertCSVtoARFF(String csvFileName, String arffFileName) throws FraudDetectorException {
		try {
			CSVLoader csvLoader = new CSVLoader();
			csvLoader.setSource(new File(csvFileName));
			Instances csvInst = csvLoader.getDataSet();

			ArffSaver arffSaver = new ArffSaver();
			arffSaver.setInstances(csvInst);
			arffSaver.setFile(new File(arffFileName));
			arffSaver.writeBatch();
		} catch (IOException ioe) {
			//throw new FraudDetectorException("Problem occured in conversion of CSV file");
			ioe.printStackTrace();
		}
	}

	public StringBuffer detectFraud(String filePath) throws FraudDetectorException {
		StringBuffer result = null;
		try {
			convertCSVtoARFF(FraudDetectorConstants.CSV_TRAINDATA_FILE_PATH,
					FraudDetectorConstants.ARFF_TRAINDATA_FILE_PATH);
			convertCSVtoARFF(filePath, FraudDetectorConstants.ARFF_TESTDATA_FILE_PATH);
		} catch (FraudDetectorException fe) {
			//throw new FraudDetectorException(fe.getMessage());
			fe.printStackTrace();
		}

		try {
			result = new StringBuffer();
			
			DataSource trainDataSource = new DataSource(FraudDetectorConstants.ARFF_TRAINDATA_FILE_PATH);
			Instances trainDataSet = trainDataSource.getDataSet();
			trainDataSet.setClassIndex(trainDataSet.numAttributes() - 1);

			Logistic logisticRegression = new Logistic();
			logisticRegression.buildClassifier(trainDataSet);

			DataSource testDataSource = new DataSource(FraudDetectorConstants.ARFF_TESTDATA_FILE_PATH);
			Instances testDataSet = testDataSource.getDataSet();
			testDataSet.setClassIndex(testDataSet.numAttributes() - 1);

			for (int i = 0; i < testDataSet.numInstances();i++) {
				Instance newInstance = testDataSet.instance(i);
				double prediction = logisticRegression.classifyInstance(newInstance);
				if (prediction == 0)
					result.append(i+ ". " +"Fraud");
				else
					result.append(i+ ". " +"Honest");
			}
		} catch (Exception e) {
			e.printStackTrace();
			//throw new FraudDetectorException("Something went wrong");
		}
		return result;
	}
}
